<nav class="py-6">
    <a href="{{ route('home') }}">
        <img
            class="w-36"
            src="{{ asset('img/enjob-logo.svg') }}"
            alt="Logo da empresa"
        >
    </a>
</nav>
